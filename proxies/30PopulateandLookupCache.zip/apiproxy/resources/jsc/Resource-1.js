    // Get the value from the LookupCache policy
    var cachedValue = context.getVariable('latlngcache');

    print(cachedValue)

    if (cachedValue) {
        // Split the value by a delimiter (e.g., a comma)
        var parts = cachedValue.split(',');

        // Set new flow variables with the split parts
        if (parts.length > 0) {
            context.setVariable('latcache', parts[0]);
        }
        if (parts.length > 1) {
            context.setVariable('lngcache', parts[1]);
        }
        // Add more conditions for additional parts as needed
    } else {
        // Handle the case where the cached value is not found or is empty
        context.setVariable('error.message', 'Cached value not found or empty.');
    }