// extract verb and set messageWeight variable to respective weights 

var verb = context.getVariable("request.verb");
if(verb == 'GET')
  context.setVariable("messageWeight","1");
if(verb == 'POST')
  context.setVariable("messageWeight","2");
