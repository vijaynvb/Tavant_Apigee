var address = context.getVariable('address');

var responsePayload = JSON.parse(context.getVariable('response.content'));

try {

  responsePayload.placeAddress = address;
  responsePayload.comment = "This is the TOP result for input place name";
  context.setVariable('response.content', JSON.stringify(responsePayload));
  context.setVariable('isPayloadModified','Yes');

}
catch(e) {

  print('There is ERROR in Payload Modification');
  context.setVariable('isPayloadModified','No');

}