print(context.getVariable("cityQueryParams.firstCity"));
print(context.getVariable("cityQueryParams.secondCity"));