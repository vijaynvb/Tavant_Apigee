// Get the response from the ServiceCallout
var response = context.getVariable("calloutResponse");
var response1 = context.getVariable("calloutResponse.response");
var response2 = context.getVariable("calloutResponse.status.code");
// Log the response
print("ServiceCallout Response: " + response);
print("ServiceCallout Response: " + response1);
print("ServiceCallout Response: " + response2);